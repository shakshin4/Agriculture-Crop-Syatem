const Razorpay = require('razorpay');
const RAZERPAY_KEY_ID = 'rzp_test_EeNH6kj1N5ttbY';
const RAZERPAY_KEY_SECRET = '5cwVz1ARlZsrjvex8PCiDhHh';
const RAZERPAY_SECRET_MESSAGE = 'webhookpayment';

const razorpayId = RAZERPAY_KEY_ID;
const razorpaySecret = RAZERPAY_KEY_SECRET;
const razorpay = new Razorpay({
  key_id: razorpayId,
  key_secret: razorpaySecret,
});

module.exports = razorpay;
