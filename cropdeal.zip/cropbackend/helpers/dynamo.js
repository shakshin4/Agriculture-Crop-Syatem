const AWS = require('aws-sdk');

const AWS_BUCKET_NAME = 'my-project-images-bucket';
const AWS_REGION = 'us-west-2';
const AWS_ACCESS_KEY = 'AKIASZTLTTRYIY55AC7G';
const AWS_SECRET_KEY = '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';

AWS.config.update({
  region: AWS_REGION,
  accessKeyId: AWS_ACCESS_KEY,
  secretAccessKey: AWS_SECRET_KEY,
});

const dynamoClient = new AWS.DynamoDB.DocumentClient();
const TABLE_NAME = 'crop-purchase-data';

const getCharacters = async () => {
  const params = {
    TableName: TABLE_NAME,
  };
  const characters = await dynamoClient.scan(params).promise();
  return characters;
};

const addOrUpdateCharacters = async (data) => {
  const params = {
    TableName: TABLE_NAME,
    Item: data,
  };
  return await dynamoClient.put(params).promise();
};

const getCharacterById = async (id) => {
  const params = {
    TableName: TABLE_NAME,
    Key: {
      id,
    },
  };
  return await dynamoClient.put(params).promise();
};

const deleteCharacter = async (id) => {
  const params = {
    TableName: TABLE_NAME,
    Key: {
      id,
    },
  };
  return await dynamoClient.delete(params).promise();
};

module.exports = {
  getCharacters,
  addOrUpdateCharacters,
  getCharacterById,
  deleteCharacter,
};
