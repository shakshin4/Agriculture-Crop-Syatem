const jwt = require('jsonwebtoken');

//create  taoken
const maxAge = 3 * 24 * 60 * 60;
const createToken = (id) => {
  return jwt.sign({ id }, 'shakshi secret', {
    
    //to set the expire(how long the jwt can be valid for)
    expiresIn: maxAge,
  });
};

module.exports = createToken;
