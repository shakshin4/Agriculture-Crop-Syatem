const { S3 } = require('aws-sdk');
const crypto = require('crypto');
const { promisify } = require('util');
const randomBytes = promisify(crypto.randomBytes);

const AWS_BUCKET_NAME = 'my-project-images-bucket';
const AWS_BUCKET_REGION = 'us-west-2';
const AWS_ACCESS_KEY = 'AKIASZTLTTRYIY55AC7G';
const AWS_SECRET_KEY = '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';

const s3 = new S3({
  region: AWS_BUCKET_REGION,
  accessKeyId: AWS_ACCESS_KEY,
  secretAccessKey: AWS_SECRET_KEY,
  signatureVersion: 'v4',
});

const generateUploadUrl = async () => {
  const rawBytes = await randomBytes(16);
  const imageName = rawBytes.toString('hex');

  const params = {
    Bucket: AWS_BUCKET_NAME,
    Key: imageName,
    Expires: 60,
  };
  const uploadUrl = await s3.getSignedUrlPromise('putObject', params);
  return uploadUrl;
};

const getFileStream = (fileKey) => {
  const downloadParams = {
    Key: fileKey,
    Bucket: AWS_BUCKET_NAME,
  };
  return s3.getObject(downloadParams).createReadStream();
};

module.exports = { generateUploadUrl, getFileStream };
