const express = require('express');
const mongoose = require('mongoose');
const authRoutes = require('./routes/authRoutes.js');
const farmerRoute = require('./routes/farmerRoutes.js');
const adminRoute = require('./routes/adminRoute');
const imageRoute = require('./routes/imageRoute.js');
const paymentRoute = require('./routes/payment');

const cors = require('cors');
const app = express();

app.use(express.static('public'));
app.use(express.json());
app.use(cors());

const dbURI =
  'mongodb+srv://myCluster:leavemealone@cluster0-n1vtu.mongodb.net/tell-tale-api?retryWrites=true&w=majority';
mongoose
  .connect(dbURI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    useCreateIndex: true,
    findAndModify: false,
  })
  .then((result) =>
    app.listen(3000, () => {
      console.log('Server is running');
    })
  )
  .catch((err) => console.log(err));

app.use('/farmer', authRoutes);
app.use('/dealer', authRoutes);
app.use('/admin', authRoutes);
app.use(farmerRoute);
app.use(imageRoute);
app.use(paymentRoute);
app.use(adminRoute);
module.exports = app;