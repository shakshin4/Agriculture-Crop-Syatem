const { Router } = require('express');
const router = Router();
const razorpay = require('../helpers/razorpay');
const { v4: uuidv4 } = require('uuid'); // is library se unique id generate karte hai
const {
  getCharacters,
  addOrUpdateCharacters,
  getCharacterById,
  deleteCharacter,
} = require('../helpers/dynamo');

router.post('/razorpay', async (req, res) => {
  const { amount } = req.body;

  const currency = 'INR';
  const receipt = uuidv4();
  try {
    const options = {
      amount: amount * 100,
      currency,
      receipt,
    };

    const response = await razorpay.orders.create(options);
    res.status(201).json({
      id: response.id,
      currency: response.currency,
      amount: response.amount,
    });
  } catch (error) {
    console.log(error);
    res.status(500).send(error);
  }
});

router.post('/razorpay/callback', async (req, res) => {
  try {
    console.log('OrderData : ', req.body);
    const dynamoSaveData = { id: uuidv4(), ...req.body };
    await addOrUpdateCharacters(dynamoSaveData);
    res.sendStatus(200);
  } catch (error) {
    console.log(error);
  }
});

module.exports = router;
