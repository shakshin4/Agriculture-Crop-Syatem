const { Router } = require('express');
const router = Router();
const Farmer = require('../models/Farmer');
const Dealer = require('../models/Dealer');
const Admin = require('../models/Admin');

router.get('/getallfarmers', async (req, res) => {
  try {
    const allUsers = await Farmer.find();
    const result = [];
    if (Array.isArray(allUsers)) {
      allUsers.forEach((user) => {
        const data = {
          id: user._id,
          name: user.name,
          address: user.address,
          email: user.email,
          authorized: user.authorized,
          type: 'farmer',
        };
        result.push(data);
      });
    }
    res.status(200).send(result);
  } catch (err) {
    res.status(400).send(err);
  }
});

router.get('/getalldealers', async (req, res) => {
  try {
    const allUsers = await Dealer.find();
    const result = [];
    if (Array.isArray(allUsers)) {
      allUsers.forEach((user) => {
        const data = {
          id: user._id,
          name: user.name,
          address: user.address,
          email: user.email,
          authorized: user.authorized,
          type: 'dealer',
        };
        result.push(data);
      });
    }
    res.status(200).send(result);
  } catch (err) {
    res.status(400).send(err);
  }
});

router.post('/authorizefarmer', async (req, res) => {
  try {
    const { id, authorized } = req.body;
    console.log("+++++++++",id)
    const user = await Farmer.findByIdAndUpdate(id, { authorized: authorized });
    const data = {
      id: user._id,
      name: user.name,
      address: user.address,
      email: user.email,
      authorized: user.authorized,
      type: 'farmer',
    };
    res.status(200).send(data);
  } catch (err) {
    console.log(err,"**********")
    res.status(400).send(err);
    
  }
});

router.post('/authorizedealer', async (req, res) => {
  try {
    const { id, authorized } = req.body;
   
    const user = await Dealer.findByIdAndUpdate(id, { authorized: authorized });
    const data = {
      id: user._id,
      name: user.name,
      address: user.address,
      email: user.email,
      authorized: user.authorized,
      type: 'dealer',
    };
    res.status(200).send(data);
  } catch (err) {
    res.status(400).send(err);
  }
});

router.post('/verifyfarmer', async (req, res) => {
  try {
    const { id } = req.body;
    const user = await Farmer.findById(id);
    if (!user.authorized) {
      res.status(200).send({ authorized: false });
      return;
    }
    res.status(200).send({ authorized: true });
  } catch (err) {
    res.status(400).send(err);
  }
});

router.post('/verifydealer', async (req, res) => {
  try {
    const { id } = req.body;
    const user = await Dealer.findById(id);
    if (!user.authorized) {
      res.status(200).send({ authorized: false });
      return;
    }
    res.status(200).send({ authorized: true });
  } catch (err) {
    res.status(400).send(err);
  }
});

module.exports = router;
