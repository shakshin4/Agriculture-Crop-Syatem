const { Router } = require('express');
const Crop = require('../models/Crop');
const Farmer = require('../models/Farmer');
const router = Router();

router.post('/farmer/addcrop', async (req, res) => {
  try {
    const { name, price, quantity, picture, farmerId } = req.body;
    const crop = await Crop.create({
      name,
      price,
      quantity,
      picture,
      farmer: farmerId,
    });
    const result = {
      id: crop._id,
      name: crop.name,
      price: crop.price,
      quantity: crop.quantity,
      picture: crop.picture,
      farmerId: crop.farmer,
    };

    res.status(201).json(result);
  } catch (err) {
    console.log('Error :', err.message);
    res.status(400).json(err.message);
  }
});

router.post('/farmer/removecrop', async (req, res) => {
  try {
    const cropId = req.body.id;
    await Crop.findByIdAndDelete(cropId);
    res.status(200).send({ message: 'Deleted successfully' });
  } catch (err) {
    res.status(400).send({ message: 'Crop deletion failed' });
  }
});

router.post('/farmer/name', async (req, res) => {
  try {
    const farmerId = req.body.farmerId;
    const farmer = await Farmer.findById(farmerId);
    res.status(200).send({ farmerName: farmer.name });
  } catch (err) {
    res.status(400).send({ message: 'Couldnt get farmer name' });
  }
});

router.get('/farmer/allcrops', async (req, res) => {
  try {
    const allCrops = await Crop.find();
    const result = [];
    if (Array.isArray(allCrops)) {
      allCrops.forEach((crop) => {
        const data = {
          id: crop._id,
          name: crop.name,
          price: crop.price,
          quantity: crop.quantity,
          picture: crop.picture,
          farmerId: crop.farmer,
        };
        result.push(data);
      });
    }
    res.status(200).send(result);
  } catch (err) {
    res.status(400).send(err);
  }
});

module.exports = router;
