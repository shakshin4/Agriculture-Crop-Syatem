//destructure the router from the express package
const { Router } = require('express');
const createToken = require('../helpers/createToken');
const handleErrors = require('../helpers/handleError.js');
const Farmer = require('../models/Farmer');
const Dealer = require('../models/Dealer');
const Admin = require('../models/Admin');
const router = Router();

const getUserType = (url) => {
  if (url.includes('farmer')) return Farmer;

  if (url.includes('dealer')) return Dealer;

  if (url.includes('admin')) return Admin;
};

router.post('/register', async (req, res) => {
  const UserSchema = getUserType(req.originalUrl);

  try {
    const { name, email, password, address } = req.body;
    const user = await UserSchema.create({ email, password, name, address });
    const token = createToken(user._id);
    const result = {
      id: user._id,
      name: user.name,
      address: user.address,
      email: user.email,
      token: token,
      authorized: user.authorized,
    };
    res.status(201).json(result);
  } catch (err) {
    res.status(400).json(handleErrors(err));
  }
});

router.post('/login', async (req, res) => {
  const UserSchema = getUserType(req.originalUrl);
  try {
    const { email, password } = req.body;
    const user = await UserSchema.login(email, password);
    const token = createToken(user._id);
    const result = {
      id: user._id,
      name: user.name,
      address: user.address,
      email: user.email,
      token: token,
    };
    res.status(201).json(result);
  } catch (err) {
    res.status(400).json(handleErrors(err));
  }
});

module.exports = router;
