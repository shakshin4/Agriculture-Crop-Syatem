const { Router } = require('express');
const router = Router();
const { getFileStream } = require('../helpers/s3');
const { generateUploadUrl } = require('../helpers/s3');

router.get('/image/:key', (req, res) => {
  const key = req.params.key;
  const readStream = getFileStream(key);
  readStream.pipe(res);
});

router.get('/s3Url', async (req, res) => {
  const url = await generateUploadUrl();
  res.send({ url });
});

module.exports = router;
