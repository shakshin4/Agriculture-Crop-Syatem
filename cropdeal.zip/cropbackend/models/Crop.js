const mongoose = require('mongoose');

const cropSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Please enter crop name'],
  },
  farmer: {
    type: mongoose.Schema.Types.ObjectId,
    required: [true, 'Farmer Id is required'],
    ref: 'framer',
  },
  price: {
    type: Number,
    required: [true, 'Please crop price'],
  },
  quantity: {
    type: String,
    required: [true, 'Please enter crop quantity'],
  },
  picture: {
    type: String,
  },
});


const Crop = mongoose.model('crop', cropSchema);
module.exports = Crop;
