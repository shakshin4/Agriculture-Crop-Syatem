const mongoose = require('mongoose');
const { isEmail } = require('validator');
const bcrypt = require('bcrypt');

const dealerSchema = new mongoose.Schema({
  email: {
    type: String,
    required: [true, 'Please Enter an email'],
    lowercase: true,
    validate: [isEmail, 'Please enter a valid email'],
    unique: true,
  },
  password: {
    type: String,
    required: [true, 'Please Enter the Password'],
    minlength: [6, 'Minimum password length is 6 characters'],
  },
  name: {
    type: String,
    required: [true, 'Please Enter the Name'],
  },
  address: {
    type: String,
    required: [true, 'Please enter your address'],
  },
  authorized: {
    type: Boolean,
    default: false,
  },
});

// fire a function before doc saved to db
dealerSchema.pre('save', async function (next) {
  const salt = await bcrypt.genSalt();
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

//static method to login user
dealerSchema.statics.login = async function (email, password) {
  const dealer = await this.findOne({ email: email });
  if (dealer) {
    const auth = await bcrypt.compare(password, dealer.password);
    if (auth) {
      return dealer;
    }
    throw Error('Incorrect password');
  }
  throw Error('incorret email');
};

const Dealer = mongoose.model('dealer', dealerSchema);
module.exports = Dealer;
