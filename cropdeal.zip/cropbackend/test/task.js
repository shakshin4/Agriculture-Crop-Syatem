let chai = require("chai");
let chaiHttp = require("chai-http");
const { response } = require("express");
let Server = require("../app");
// assertion style
chai.should();
chai.use(chaiHttp);
describe('Tasks API',() =>{
    // test GET route
    describe("GET /getallfarmers", () => {
        it('It should get all the tasks', (done) => {
            chai.request(Server)
            .get("/getallfarmers")
            .end((err, response) => {
                response.should.have.status(200);
                response.body.should.be.a('array');
               // response.body.length.should.be.eq(3);
            done();
            })
        }).timeout(10000);

    })
    //Test the GET (by id) route
    describe("GET /getalldealers", () => {
        it('It should get all the tasks', (done) => {
            chai.request(Server)
            .get("/getalldealers")
            .end((err, response) => {
                response.should.have.status(200);
                response.body.should.be.an('array');
               // response.body.length.should.be.eq(3);
            done();
            })
        }).timeout(10000);

    })
    describe("GET /getalldealers", () => {
        it('It should get all the tasks', (done) => {
            chai.request(Server)
            .get("/getalldealers")
            .end((err, response) => {
                response.should.not.have.status(300);
                response.body.should.be.an('array');
               // response.body.length.should.be.eq(3);
            done();
            })
        }).timeout(10000);

    })
    describe("GET /getalldealers", () => {
        it('It should get all the tasks', (done) => {
            chai.request(Server)
            .get("/getalldealers")
            .end((err, response) => {
                response.should.not.have.status(300);
                response.body.should.not.be.a('string');
               // response.body.length.should.be.eq(3);
            done();
            })
        }).timeout(10000);

    })
    describe("POST /getalldealers", () => {
        it('It should get wrong status ', (done) => {
            chai.request(Server)
            .get("/getalldealers")
            .end((err, response) => {
                response.should.not.have.status(300);
                response.body.should.be.an('array');
               // response.body.length.should.be.eq(3);
            done();
            })
        }).timeout(10000);

    })
    describe("POST /getalldealers", () => {
        it('It should get wrong status ', (done) => {
            chai.request(Server)
            .get("/getalldealers")
            .end((err, response) => {
                response.should.not.have.status(300);
                response.body.should.not.be.an('string');
               // response.body.length.should.be.eq(3);
            done();
            })
        }).timeout(10000);

    })
    describe("GET /getallfarmers", () => {
        it('It should return wrong status', (done) => {
            chai.request(Server)
            .get("/getallfarmers")
            .end((err, response) => {
                response.should.not.have.status(300);
                response.body.should.be.a('array');
               // response.body.length.should.be.eq(3);
            done();
            })
        }).timeout(10000);

    })
    describe("GET /getallfarmers", () => {
        it('It should not be a String', (done) => {
            chai.request(Server)
            .get("/getallfarmers")
            .end((err, response) => {
                response.should.have.status(200);
                response.body.should.not.be.a('string');
               // response.body.length.should.be.eq(3);
            done();
            })
        }).timeout(10000);

    })
    describe("GET /farmer/allcrops", () => {
        it('It should not be a String', (done) => {
            chai.request(Server)
            .get("/getallfarmers")
            .end((err, response) => {
                response.should.have.status(200);
                response.body.should.not.be.a('string');
               // response.body.length.should.be.eq(3);
            done();
            })
        }).timeout(10000);

    })
    describe("POST /authorizefarmer", () => {
        it('This is the post request for farmer ', (done) => {
            chai.request(Server)
            .post("/authorizefarmer")
            .set('content-type', 'application/json')
            .send({id: '6149c3f0cf90fd20c41b4be8',
            authorized: true})
        
            .end((err, response) => {
                response.should.have.status(200);
                response.body.should.be.an('object');
               // response.body.length.should.be.eq(3);
            done();
            })
        }).timeout(10000);

    })

    describe("POST /authorizedealer", () => {
        it('This is the post request for dealer ', (done) => {
            chai.request(Server)
            .post("/authorizedealer")
            .set('content-type', 'application/json')
            .send({id: '6149c418cf90fd20c41b4bed',
            authorized: true})
        
            .end((err, response) => {
                response.should.have.status(200);
                response.body.should.be.an('object');
               // response.body.length.should.be.eq(3);
            done();
            })
        }).timeout(10000);

    })
    describe("POST /authorizedealer", () => {
        it('It should not have status 400 ', (done) => {
            chai.request(Server)
            .post("/authorizedealer")
            .set('content-type', 'application/json')
            .send({id: '6149c418cf90fd20c41b4bed',
            authorized: true})
        
            .end((err, response) => {
                response.should.not.have.status(400);
                response.body.should.be.an('object');
               // response.body.length.should.be.eq(3);
            done();
            })
        }).timeout(10000);

    })
    describe("POST /authorizefarmer", () => {
        it('It should not have status 400 ', (done) => {
            chai.request(Server)
            .post("/authorizefarmer")
            .set('content-type', 'application/json')
            .send({id: '6149c3f0cf90fd20c41b4be8',
            authorized: true})
        
            .end((err, response) => {
                response.should.not.have.status(400);
                response.body.should.be.an('object');
               // response.body.length.should.be.eq(3);
            done();
            })
        }).timeout(10000);

    })

    describe("POST /authorizefarmer", () => {
        it('It should not return a string ', (done) => {
            chai.request(Server)
            .post("/authorizefarmer")
            .set('content-type', 'application/json')
            .send({id: '6149c3f0cf90fd20c41b4be8',
            authorized: true})
        
            .end((err, response) => {
                response.should.not.have.status(400);
                response.body.should.not.be.a('string');
               // response.body.length.should.be.eq(3);
            done();
            })
        }).timeout(10000);

    })


    describe("POST /verifyfarmer", () => {
        it('This is the post request for verifying farmer ', (done) => {
            chai.request(Server)
            .post("/verifyfarmer")
            .set('content-type', 'application/json')
            .send({id: '6149c3f0cf90fd20c41b4be8'})
        
            .end((err, response) => {
                response.should.have.status(200);
                response.body.should.be.an('object');
               // response.body.length.should.be.eq(3);
            done();
            })
        }).timeout(10000);

    })
    describe("POST /verifyfarmer", () => {
        it('It sould not return 400 ', (done) => {
            chai.request(Server)
            .post("/verifyfarmer")
            .set('content-type', 'application/json')
            .send({id: '6149c3f0cf90fd20c41b4be8'})
        
            .end((err, response) => {
                response.should.not.have.status(400);
                response.body.should.be.an('object');
               // response.body.length.should.be.eq(3);
            done();
            })
        }).timeout(10000);

    })

    describe("POST /verifydealer", () => {
        it('This is the post request for verifying farmer ', (done) => {
            chai.request(Server)
            .post("/verifydealer")
            .set('content-type', 'application/json')
            .send({id: '6149c418cf90fd20c41b4bed'})
        
            .end((err, response) => {
                response.should.have.status(200);
                response.body.should.be.an('object');
               // response.body.length.should.be.eq(3);
            done();
            })
        }).timeout(10000);

    })

    describe("POST /verifydealer", () => {
        it('This is the post request for verifying farmer ', (done) => {
            chai.request(Server)
            .post("/verifydealer")
            .set('content-type', 'application/json')
            .send({id: '6149c418cf90fd20c41b4bed'})
        
            .end((err, response) => {
                response.should.not.have.status(400);
                response.body.should.be.an('object');
               // response.body.length.should.be.eq(3);
            done();
            })
        }).timeout(10000);

    })
    describe("POST /verifydealer", () => {
        it('This is the post request for verifying farmer ', (done) => {
            chai.request(Server)
            .post("/verifydealer")
            .set('content-type', 'application/json')
            .send({id: '6149c418cf90fd20c41b4bed'})
        
            .end((err, response) => {
                response.should.have.status(200);
                response.body.should.not.be.a('string');
               // response.body.length.should.be.eq(3);
            done();
            })
        }).timeout(10000);

    })
    describe("POST /login", () => {
        it('This is a login component ', (done) => {
            chai.request(Server)
            .post("/login")
            .set('content-type', 'application/json')
            .send({email: 'abcde@gmail.com',
                    password: "merko sause pasand nai"})
        
            .end((err, response) => {
                response.should.not.have.status(200);
                response.body.should.be.an('object');
               // response.body.length.should.be.eq(3);
            done();
            })
        }).timeout(10000);

    })
    describe("POST farmer/login", () => {
        it('This is a login component ', (done) => {
            chai.request(Server)
            .post("/farmer/login")
            .set('content-type', 'application/json')
            .send({email: 'abcde@gmail.com',
            password: 'merko sause pasand nai'})
        
            .end((err, response) => {
                response.should.have.status(201);
                response.body.should.be.an('object');
               // response.body.length.should.be.eq(3);
            done();
            })
        }).timeout(10000);

    })

    describe("POST farmer/register", () => {
        it('checking the status should not be 201 ', (done) => {
            chai.request(Server)
            .post("/farmer/register")
            .set('content-type', 'application/json')
            .send({name:'ABC Farmer',
                email: 'abcde@gmail.com',
                 password: 'merko sause pasand nai',
                 address: 'Rudraprayag, Uttarakhand' })
        
            .end((err, response) => {
                response.should.not.have.status(201);
                response.body.should.be.an('object');
               // response.body.length.should.be.eq(3);
            done();
            })
        }).timeout(10000);

    })
    
    describe("POST /farmer/register", () => {
        it('Checking the response should not be string  ', (done) => {
            chai.request(Server)
            .post("/farmer/register")
            .set('content-type', 'application/json')
            .send({name:'ABC Farmer',
                email: 'abcde@gmail.com',
                 password: 'merko sause pasand nai',
                 address: 'Rudraprayag, Uttarakhand' })
        
            .end((err, response) => {
                response.should.not.have.status(201);
                response.body.should.not.be.a('string');
               // response.body.length.should.be.eq(3);
            done();
            })
        }).timeout(10000);

    })
    describe("POST /farmer/register", () => {
        it('Checking same email error ', (done) => {
            chai.request(Server)
            .post("/farmer/register")
            .set('content-type', 'application/json')
            .send({name:'ABC Farmer',
                email: 'abcde@gmail.com',
                 password: 'merko sause pasand nai',
                 address: 'Rudraprayag, Uttarakhand' })
        
            .end((err, response) => {
                response.should.have.status(400);
                response.body.should.be.a('object');
               // response.body.length.should.be.eq(3);
            done();
            })
        }).timeout(10000);

    })

    describe("POST farmer/login", () => {
        it('This is a login component ', (done) => {
            chai.request(Server)
            .post("/farmer/login")
            .set('content-type', 'application/json')
            .send({email: 'abcde@gmail.com',
            password: 'merko sause pasand nai'})
        
            .end((err, response) => {
                response.should.not.have.status(201);
                response.body.should.be.an('object');
               // response.body.length.should.be.eq(3);
            done();
            })
        }).timeout(10000);

    })


    

    








    

});
