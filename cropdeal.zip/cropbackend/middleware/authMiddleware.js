const jwt = require('jsonwebtoken');
const requireAuth = (req, res, next) => {
  const token = req.cookies.jwt;

  //check json web token exists & is verified
  if (token) {
    jwt.verify(token, 'shakshi secret', (err, decodedToken) => {
      if (err) {
        console.log(err.message);
        res.redirect('/login');
      } else {
        console.log(decodedToken);
        next();
      }
    });
  } else {
    res.redirect('/login');
  }
};
module.exports = { requireAuth };
//a middleware is a function or a set of function that is executed before the main route function. It is used for checking and validation
