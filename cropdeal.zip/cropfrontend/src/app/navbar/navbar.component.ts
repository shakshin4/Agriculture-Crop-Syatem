import { Component, OnInit } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { filter } from 'rxjs/operators';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css'],
})
export class NavbarComponent implements OnInit {
  currentUrl: string;
  showProfileButton: boolean;
  showLogoutButton: boolean;
  constructor(private router: Router) {
    this.currentUrl = '';
    this.showProfileButton = false;
    this.showLogoutButton = false;
  }

  ngOnInit(): void {
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        this.currentUrl = event.url;
        this.checkShowProfileButton();
        this.checkLogoutButton();
      }
    });
  }

  checkShowProfileButton() {
    if (
      this.currentUrl.endsWith('farmer') ||
      this.currentUrl.endsWith('dealer') ||
      this.currentUrl.endsWith('admin')
    ) {
      this.showProfileButton = true;
    } else {
      this.showProfileButton = false;
    }
  }

  checkLogoutButton() {
    if (
      this.currentUrl === '/' ||
      this.currentUrl.includes('register') ||
      this.currentUrl.includes('login')
    ) {
      this.showLogoutButton = false;
    } else {
      this.showLogoutButton = true;
    }
  }

  handleShowProfile() {
    if (this.currentUrl.endsWith('farmer')) {
      this.router.navigate(['/farmer/profile']);
    } else if (this.currentUrl.endsWith('dealer')) {
      this.router.navigate(['/dealer/profile']);
    } else if (this.currentUrl.endsWith('admin')) {
      this.router.navigate(['/admin/profile']);
    } else {
      return;
    }
  }

  handleLogout() {
    localStorage.removeItem('user');
    this.router.navigate(['/']);
  }
}
