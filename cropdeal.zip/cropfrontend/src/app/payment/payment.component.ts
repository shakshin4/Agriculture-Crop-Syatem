import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../authentication.service';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css'],
})
export class PaymentComponent implements OnInit {
  key = 'rzp_test_EeNH6kj1N5ttbY';
  name: string = ''; //Route Input
  price: number = 0; //Route Input
  email: string = ''; //Route Input
  options: any;
  rzp1: any;
  dealerId = '';
  farmerId = '';
  cropId = '';
  verifyFarmer = false;
  verifyDealer = false;

  constructor(
    private window: Window,
    private router: Router,
    private authenticationService: AuthenticationService,
    private http: HttpClient
  ) {
    this.name = this.router.getCurrentNavigation()?.extras?.state?.name;
    this.price = this.router.getCurrentNavigation()?.extras?.state?.price;
    this.email = this.router.getCurrentNavigation()?.extras?.state?.email;
    this.farmerId = this.router.getCurrentNavigation()?.extras?.state?.farmerId;
    this.dealerId = this.router.getCurrentNavigation()?.extras?.state?.dealerId;
    this.cropId = this.router.getCurrentNavigation()?.extras?.state?.cropId;
  }

  ngOnInit(): void {
    if (!this.name || !this.farmerId || !this.dealerId) {
      return;
    }

    this.verifyPurchaseDealer();
    this.verifyPurchaseFarmer();

    fetch('http://localhost:3000/razorpay', {
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
      method: 'POST',
      body: JSON.stringify({ amount: this.price }),
    }).then(async (res) => {
      const returnData = await res.json();

      const options = {
        key: `${this.key}`,
        amount: returnData.amount,
        currency: returnData.currency,
        name: 'Crop Corp',
        description: 'Test Transaction',
        image: '../../../assets/images/farmer-icon.jpg',
        order_id: returnData.id,
        handler: (response: any) => {
          try {
            const dataToSave = {
              razorpay_order_id: response.razorpay_order_id,
              razorpay_payment_id: response.razorpay_payment_id,
              razorpay_signature: response.razorpay_signature,
              farmerId: this.farmerId,
              dealerId: this.dealerId,
              cropId: this.cropId,
            };

            const url = 'http://localhost:3000/razorpay/callback';
            fetch(url, {
              method: 'POST',
              headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
              },
              body: JSON.stringify(dataToSave),
            }).then((data) => {
              console.log(dataToSave);
              this.authenticationService.openSnackBar(
                'Successfully Purchased the given item'
              );
            });
          } catch (error) {
            console.log(error);
          }
        },

        prefill: {
          name: this.name,
          email: this.email,
          contact: '5748392745',
        },
        notes: {
          address: 'Crop Corp Corporate Office',
        },
        theme: {
          color: '#3399cc',
        },
      };

      this.options = options;
      this.rzp1 = new (this.window as any).Razorpay(this.options);
    });
  }

  openRazorPay() {
    this.rzp1.open();
  }

  verifyPurchaseFarmer() {
    fetch('http://localhost:3000/verifyfarmer', {
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
      method: 'POST',
      body: JSON.stringify({ id: this.farmerId }),
    })
      .then(async (res) => {
        const returnData = await res.json();
        this.verifyFarmer = returnData.authorized;
        if (!this.verifyFarmer) {
          this.authenticationService.openSnackBar(
            'farmer is not verified by admin'
          );
        }
      })
      .catch((error) => {
        console.log(error);
        this.verifyFarmer = false;
      });
  }

  verifyPurchaseDealer() {
    fetch('http://localhost:3000/verifydealer', {
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
      method: 'POST',
      body: JSON.stringify({ id: this.dealerId }),
    })
      .then(async (res) => {
        const returnData = await res.json();
        this.verifyDealer = returnData.authorized;
        if (!this.verifyDealer) {
          this.authenticationService.openSnackBar(
            'Dealer is not verified by admin'
          );
        }
      })
      .catch((error) => {
        console.log(error);
        this.verifyDealer = false;
      });
  }
}
