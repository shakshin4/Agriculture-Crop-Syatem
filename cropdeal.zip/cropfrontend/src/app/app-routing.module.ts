import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminComponent } from './Admin/admin/admin.component';
import { LoginComponent } from './Auth/login/login.component';
import { RegisterComponent } from './Auth/register/register.component';
import { DealerComponent } from './Dealer/dealer/dealer.component';
import { FarmerComponent } from './Farmer/farmer/farmer.component';
import { HomeComponent } from './Home/home/home.component';
import { PaymentComponent } from './payment/payment.component';
import { ProfileComponent } from './profile/profile.component';

const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'dealer', component: DealerComponent },
  { path: 'farmer', component: FarmerComponent },
  { path: 'admin', component: AdminComponent },
  { path: 'admin/register', component: RegisterComponent },
  { path: 'admin/login', component: LoginComponent },
  { path: 'farmer/register', component: RegisterComponent },
  { path: 'farmer/login', component: LoginComponent },
  { path: 'dealer/register', component: RegisterComponent },
  { path: 'dealer/login', component: LoginComponent },
  { path: 'admin/profile', component: ProfileComponent },
  { path: 'farmer/profile', component: ProfileComponent },
  { path: 'dealer/profile', component: ProfileComponent },
  { path: 'payment', component: PaymentComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
