import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { IUser } from 'src/app/Auth/IUser';
import { AuthenticationService } from 'src/app/authentication.service';


@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css'],
})
export class AdminComponent implements OnInit {
  allFarmers: IUser[];
  allDealers: IUser[];
  currentUser: IUser | null;

  constructor(
    private http: HttpClient,
    private authenticationService: AuthenticationService,
    private router: Router
  ) {
    this.allFarmers = [];
    this.allDealers = [];
    this.currentUser = this.authenticationService.getUserDetails();
    if (!this.currentUser || this.currentUser.type !== 'admin') {
      this.router.navigate(['/admin/register']);
    }
  }

  ngOnInit(): void {
    this.getAllDealers();
    this.getAllFarmers();
  }

  getAllFarmers() {
    const url = 'http://localhost:3000/getallfarmers';
    this.http
      .get<IUser[]>(url)
      .toPromise()
      .then((data) => {
        this.allFarmers = data;
      })
      .catch((error) => {
        console.log(error);
      });
  }

  getAllDealers() {
    const url = 'http://localhost:3000/getalldealers';
    this.http
      .get<IUser[]>(url)
      .toPromise()
      .then((data) => {
        this.allDealers = data;
      })
      .catch((error) => {
        console.log(error);
      });
  }
  authorizeFarmer(data: { id: string; authorized: boolean }) {
    const url = 'http://localhost:3000/authorizefarmer';
    this.http
      .post<IUser>(url, data)
      .toPromise()
      .then((data) => {
        const user = data;
        this.getAllFarmers();
      })
      .catch((error) => {
        console.log(error);
      });
  }

  authorizeDealer(data: { id: string; authorized: boolean }) {
    const url = 'http://localhost:3000/authorizedealer';
    this.http
      .post<IUser>(url, data)
      .toPromise()
      .then((data) => {
        const user = data;
        this.getAllDealers();
      })
      .catch((error) => {
        console.log(error);
      });
  }
}


