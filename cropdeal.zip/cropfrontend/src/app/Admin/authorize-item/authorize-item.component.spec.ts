import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AuthorizeItemComponent } from './authorize-item.component';

describe('AuthorizeItemComponent', () => {
  let component: AuthorizeItemComponent;
  let fixture: ComponentFixture<AuthorizeItemComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AuthorizeItemComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AuthorizeItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
