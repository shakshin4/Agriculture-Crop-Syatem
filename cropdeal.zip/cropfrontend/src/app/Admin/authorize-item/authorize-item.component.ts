import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { IUser } from 'src/app/Auth/IUser';

@Component({
  selector: 'app-authorize-item',
  templateUrl: './authorize-item.component.html',
  styleUrls: ['./authorize-item.component.css'],
})
export class AuthorizeItemComponent implements OnInit {
  @Input() user: IUser | null;
  @Output() authorize: EventEmitter<{ id: string; authorized: boolean }> =
    new EventEmitter();
  constructor() {
    this.user = null;
  }

  ngOnInit(): void {}
  handleAuthorize() {
    this.authorize.emit({
      id: this.user!.id,
      authorized: !this.user!.authorized,
    });
  }
}
