import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './Home/home/home.component';
import { NavbarComponent } from './navbar/navbar.component';
import { AdminComponent } from './Admin/admin/admin.component';
import { FarmerComponent } from './Farmer/farmer/farmer.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MaterialModule } from './material/material.module';
import { DealerComponent } from './Dealer/dealer/dealer.component';
import { RegisterComponent } from './Auth/register/register.component';
import { LoginComponent } from './Auth/login/login.component';
import { CropItemComponent } from './Farmer/crop-item/crop-item.component';
import { AddCropComponent } from './Farmer/add-crop/add-crop.component';
import { DealerCropItemComponent } from './Dealer/dealer-crop-item/dealer-crop-item.component';
import { PaymentComponent } from './payment/payment.component';
import { ProfileComponent } from './profile/profile.component';
import { AuthorizeItemComponent } from './Admin/authorize-item/authorize-item.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    NavbarComponent,
    AdminComponent,
    FarmerComponent,
    DealerComponent,
    RegisterComponent,
    LoginComponent,
    CropItemComponent,
    AddCropComponent,
    DealerCropItemComponent,
    PaymentComponent,
    ProfileComponent,
    AuthorizeItemComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    MaterialModule,
  ],
  providers: [{ provide: Window, useValue: window }],
  bootstrap: [AppComponent],
})
export class AppModule {}
