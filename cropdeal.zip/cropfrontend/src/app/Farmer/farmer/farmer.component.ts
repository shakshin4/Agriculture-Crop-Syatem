import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { IUser } from 'src/app/Auth/IUser';
import { AuthenticationService } from 'src/app/authentication.service';
import { CropsService } from 'src/app/crops.service';
import { ICrop } from '../ICrop';

@Component({
  selector: 'app-farmer',
  templateUrl: './farmer.component.html',
  styleUrls: ['./farmer.component.css'],
})
export class FarmerComponent implements OnInit {
  allCrops: ICrop[];
  currentUser: IUser | null;
  constructor(
    private router: Router,
    private cropsService: CropsService,
    private authenticationService: AuthenticationService
  ) {
    this.allCrops = [];
    this.currentUser = this.authenticationService.getUserDetails();
    if (!this.currentUser || this.currentUser.type !== 'farmer') {
      this.router.navigate(['/farmer/register']);
      return;
    }
  }

  ngOnInit(): void {
    this.updateCrops();
  }

  updateCrops() {
    this.cropsService
      .getAllCrops()
      .then((data) => {
        this.allCrops = data;
      })
      .catch((error) => {
        console.log('Unable to get all crops', error);
      });
  }
}
