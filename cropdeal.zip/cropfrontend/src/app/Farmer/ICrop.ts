export interface ICrop {
  id: string;
  name: string;
  price: number;
  quantity: number;
  picture: string;
  farmerId: string;
}
