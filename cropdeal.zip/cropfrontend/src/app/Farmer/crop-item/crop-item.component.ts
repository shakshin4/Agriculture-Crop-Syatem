import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { AuthenticationService } from 'src/app/authentication.service';
import { CropsService } from 'src/app/crops.service';
import { ICrop } from '../ICrop';

@Component({
  selector: 'app-crop-item',
  templateUrl: './crop-item.component.html',
  styleUrls: ['./crop-item.component.css'],
})
export class CropItemComponent implements OnInit {
  @Input() crop: ICrop;
  imageData: any;
  baseUrl: string = 'http://localhost:3000';
  @Output() cropsChanged: EventEmitter<string> = new EventEmitter();
  constructor(
    private cropsService: CropsService,
    private authenticationService: AuthenticationService
  ) {
    const farmer = authenticationService.getUserDetails();
    const farmerId = farmer?.id || '';
    this.crop = {
      id: '',
      name: '',
      price: 0,
      quantity: 0,
      picture: '',

      farmerId: farmerId,
    };
  }

  ngOnInit(): void {}

  handleDeleteCrop() {
    this.imageData = this.cropsService
      .deleteCrop(this.crop.id)
      .then((data) => {
        console.log(data);
        this.cropsChanged.emit('Crops Changed');
        this.authenticationService.openSnackBar('Crop Deleted');
      })
      .catch((error) => {
        console.log(error);
      });
  }
}
