import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { AuthenticationService } from 'src/app/authentication.service';
import { CropsService } from 'src/app/crops.service';
import { FileuploaderService } from 'src/app/fileuploader.service';
import { v4 as uuidv4 } from 'uuid';
import { ICrop } from '../ICrop';
@Component({
  selector: 'app-add-crop',
  templateUrl: './add-crop.component.html',
  styleUrls: ['./add-crop.component.css'],
})
export class AddCropComponent implements OnInit {
  name: string;
  price: number | null;
  quantity: number | null;
  picture: string;
  fileUrl: string;
  farmerId: string;
  imageFile: File | null;
  @Output() cropsChanged: EventEmitter<string> = new EventEmitter();
  constructor(
    private fileUploaderService: FileuploaderService,
    private authenticationService: AuthenticationService,
    private cropService: CropsService
  ) {
    this.imageFile = null;
    const farmer = authenticationService.getUserDetails();
    this.name = '';
    this.price = null;
    this.quantity = null;
    this.picture = '';
    this.fileUrl = '';
    this.farmerId = '';
    if (farmer?.id) this.farmerId = farmer.id;
  }

  ngOnInit(): void {}

  validate() {
    if (!this.name || !this.price || !this.quantity || !this.fileUrl) {
      this.authenticationService.openSnackBar('Please fill all the entries');
      return false;
    }
    return true;
  }

  async handleOnSumbit() {
    if (!this.validate()) return;

    try {
      const compressedImage = await this.fileUploaderService.compressImage(
        this.imageFile!
      );

      if (!compressedImage) {
        this.authenticationService.openSnackBar('Unable to compress image');
        return;
      }

      const result: any = await this.fileUploaderService.upload(
        compressedImage,
        uuidv4()
      );

      const key = result.key;

      const cropData: ICrop = {
        id: '',
        name: this.name,
        price: this.price!,
        quantity: this.quantity!,
        picture: key,
        farmerId: this.farmerId,
      };

      this.cropService
        .addCrop(cropData)
        .then((data) => {
          this.authenticationService.openSnackBar('Crop Detils Saved');
          this.cropsChanged.emit('cropsChanged');
          this.name = '';
          this.price = null;
          this.quantity = null;
          this.picture = '';
          this.fileUrl = '';
        })
        .catch((err) => {
          console.log(err);
        });
    } catch (err) {
      console.log('ImageUpload Error: ', err);
    }
  }
  onFileChanged(e: any) {
    if (e.target.files) {
      const reader = new FileReader();
      this.imageFile = e.target.files[0];
      reader.readAsDataURL(e.target.files[0]);
      reader.onload = (event: any) => {
        this.fileUrl = event.target.result;
      };
    }
  }
}
