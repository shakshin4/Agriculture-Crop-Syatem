import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { ICrop } from './Farmer/ICrop';
import { MatSnackBar } from '@angular/material/snack-bar';
import { catchError } from 'rxjs/operators';
import { throwError } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class CropsService {
  constructor(private http: HttpClient, private snackBar: MatSnackBar) {}

  getAllCrops() {
    const url = 'http://localhost:3000/farmer/allcrops';
    return this.http.get<ICrop[]>(url).toPromise();
  }

  addCrop(cropData: ICrop) {
    const url = 'http://localhost:3000/farmer/addcrop';
    return this.http.post<ICrop>(url, cropData).toPromise();
  }

  deleteCrop(id: string) {
    console.log('Delete Crop id', id);
    const url = 'http://localhost:3000/farmer/removecrop';
    return this.http.post<any>(url, { id }).toPromise();
  }

  getFarmerName(farmerId: string) {
    const url = 'http://localhost:3000/farmer/name';
    return this.http.post<any>(url, { farmerId }).toPromise();
  }
}
