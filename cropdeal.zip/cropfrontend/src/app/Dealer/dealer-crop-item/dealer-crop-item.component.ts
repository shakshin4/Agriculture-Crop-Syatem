import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { IUser } from 'src/app/Auth/IUser';
import { AuthenticationService } from 'src/app/authentication.service';
import { CropsService } from 'src/app/crops.service';
import { ICrop } from 'src/app/Farmer/ICrop';

@Component({
  selector: 'app-dealer-crop-item',
  templateUrl: './dealer-crop-item.component.html',
  styleUrls: ['./dealer-crop-item.component.css'],
})
export class DealerCropItemComponent implements OnInit {
  @Input() crop: ICrop;
  dealer: IUser | null;
  baseUrl: string = 'http://localhost:3000';
  farmerName: string = '';
  constructor(
    private cropsService: CropsService,
    private router: Router,
    private authenticationService: AuthenticationService
  ) {
    this.crop = {
      id: '',
      name: '',
      price: 0,
      quantity: 0,
      picture: '',
      farmerId: '',
    };

    this.dealer = this.authenticationService.getUserDetails();
  }

  handleBuyCrop() {
    this.router.navigate(['/payment'], {
      state: {
        name: this.dealer?.name,
        price: this.crop.price,
        email: this.dealer?.email,
        farmerId: this.crop.farmerId,
        dealerId: this.dealer?.id,
        cropId: this.crop.id,
      },
    });
  }

  ngOnInit(): void {
    this.cropsService
      .getFarmerName(this.crop.farmerId)
      .then((data) => (this.farmerName = data.farmerName))
      .catch((error) => {
        console.log(error);
      });
  }
}
