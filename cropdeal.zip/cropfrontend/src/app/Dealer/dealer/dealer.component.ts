import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { IUser } from 'src/app/Auth/IUser';
import { AuthenticationService } from 'src/app/authentication.service';
import { CropsService } from 'src/app/crops.service';
import { ICrop } from 'src/app/Farmer/ICrop';

@Component({
  selector: 'app-dealer',
  templateUrl: './dealer.component.html',
  styleUrls: ['./dealer.component.css'],
})
export class DealerComponent implements OnInit {
  allCrops: ICrop[];
  currentUser: IUser | null;
  constructor(
    private router: Router,
    private cropsService: CropsService,
    private authenticationService: AuthenticationService
  ) {
    this.allCrops = [];
    this.currentUser = this.authenticationService.getUserDetails();
    if (!this.currentUser || this.currentUser.type !== 'dealer') {
      this.router.navigate(['/dealer/register']);
    }
  }
  ngOnInit(): void {
    this.updateCrops();
  }

  updateCrops() {
    this.cropsService
      .getAllCrops()
      .then((data) => {
        this.allCrops = data;
      })
      .catch((error) => {
        console.log('Unable to get all crops', error);
      });
  }
}
