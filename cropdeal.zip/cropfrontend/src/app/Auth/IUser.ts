export interface IUser {
  id: string;
  name: string;
  email: string;
  address: string;
  token: string;
  type: string;
  authorized: Boolean;
}
