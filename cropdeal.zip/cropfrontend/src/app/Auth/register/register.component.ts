import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from 'src/app/authentication.service';
import { IRegisterUser } from '../IRegisterUser';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
})
export class RegisterComponent implements OnInit {
  registerUser: IRegisterUser;
  type: string = '';

  constructor(
    private authenticationService: AuthenticationService,
    private router: Router
  ) {
    const farmer: IRegisterUser = {
      name: 'ABC Farmer',
      email: 'abcde@gmail.com',
      password: 'this is my password',
      confirmPassword: 'this is my password',
      address: 'Rudraprayag, Uttarakhand',
    };
    this.registerUser = farmer;
  }

  ngOnInit(): void {
    if (this.router.url.includes('farmer')) {
      this.type = 'farmer';
    } else if (this.router.url.includes('admin')) {
      this.type = 'admin';
    } else if (this.router.url.includes('dealer')) {
      this.type = 'dealer';
    }
  }

  validateData() {
    if (
      !this.registerUser.name ||
      !this.registerUser.email ||
      !this.registerUser.password ||
      !this.registerUser.confirmPassword ||
      !this.registerUser.address
    ) {
      this.authenticationService.openSnackBar('Please fill all the entries');
      return false;
    }

    if (this.registerUser.password !== this.registerUser.confirmPassword) {
      this.authenticationService.openSnackBar(
        'Password and confirm password do not match'
      );

      return false;
    }
    return true;
  }

  handleOnSumbit() {
    if (!this.validateData()) return;

    this.authenticationService
      .registerUser(this.registerUser, this.type)
      .then((data) => {
        localStorage.setItem(
          'user',
          JSON.stringify({ type: this.type, ...data })
        );
        this.authenticationService.openSnackBar('Registered Successfully');
        this.router.navigate([`/${this.type}`]);
      })
      .catch((error) => {
        console.log(error);
        this.authenticationService.openSnackBar('Something went wrong');
      });
  }
  goToLogin() {
    this.router.navigate([`/${this.type}/login`]);
  }
}
