import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from 'src/app/authentication.service';
import { ILoginUser } from '../ILoginUser';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  loginUser: ILoginUser;
  type: string = '';
  constructor(
    private authenticationService: AuthenticationService,
    private router: Router
  ) {
    const user = {
      email: 'abcde@gmail.com',
      password: 'this is my password',
    };

    this.loginUser = user;
  }

  ngOnInit(): void {
    if (this.router.url.includes('farmer')) {
      this.type = 'farmer';
    } else if (this.router.url.includes('admin')) {
      this.type = 'admin';
    } else if (this.router.url.includes('dealer')) {
      this.type = 'dealer';
    }
  }

  validateData() {
    if (!this.loginUser.email || !this.loginUser.password) {
      this.authenticationService.openSnackBar('Please fill all the entries');
      return false;
    }
    return true;
  }

  handleOnSumbit() {
    if (!this.validateData()) return;
    this.authenticationService
      .loginUser(this.loginUser, this.type)
      .then((data) => {
        localStorage.setItem(
          'user',
          JSON.stringify({ type: this.type, ...data })
        );
        this.authenticationService.openSnackBar('Login Successful');
        this.router.navigate([`/${this.type}`]);
      })
      .catch((error) => {
        console.log(error);
        this.authenticationService.openSnackBar('Something went wrong');
      });
  }

  goToRegister() {
    this.router.navigate([`/${this.type}/register`]);
  }
}
