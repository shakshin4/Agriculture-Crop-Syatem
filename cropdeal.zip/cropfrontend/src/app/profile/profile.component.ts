import { Component, Input, OnInit } from '@angular/core';
import { IUser } from '../Auth/IUser';
import { AuthenticationService } from '../authentication.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css'],
})
export class ProfileComponent implements OnInit {
  user: IUser | null;
  constructor(private authenticationService: AuthenticationService) {
    this.user = null;
  }

  ngOnInit(): void {
    this.user = this.authenticationService.getUserDetails();
  }
}
