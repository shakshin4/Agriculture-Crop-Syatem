import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { S3 } from 'aws-sdk';
import imageCompression from 'browser-image-compression';

@Injectable({
  providedIn: 'root',
})
export class FileuploaderService {
  AWS_BUCKET_NAME = 'my-project-images-bucket';
  AWS_BUCKET_REGION = 'us-west-2';
  AWS_ACCESS_KEY = 'AKIASZTLTTRYIY55AC7G';
  AWS_SECRET_KEY = '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';
  s3: S3;
  constructor(private http: HttpClient) {
    const region = this.AWS_BUCKET_REGION;
    const accessKeyId = this.AWS_ACCESS_KEY;
    const secretKey = this.AWS_SECRET_KEY;
    this.s3 = new S3({
      region,
      accessKeyId,
      secretAccessKey: secretKey,
    });
  }

  async upload(file: File, key: string) {
    const bucketName = this.AWS_BUCKET_NAME;
    const uploadParams = {
      Bucket: bucketName,
      Body: file,
      Key: key,
    };
    return this.s3.upload(uploadParams).promise();
  }

  async compressImage(imageFile: File) {
    const options = {
      maxSizeMB: 0.5,
      maxWidthOrHeight: 1920,
      useWebWorker: true,
    };
    try {
      const compressedFile = await imageCompression(imageFile, options);
      return compressedFile;
    } catch (error) {
      console.log(error);
      return null;
    }
  }
}
