import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { catchError } from 'rxjs/operators';
import { throwError } from 'rxjs';
import { IRegisterUser } from './Auth/IRegisterUser';
import { ILoginUser } from './Auth/ILoginUser';
import { IUser } from './Auth/IUser';

@Injectable({
  providedIn: 'root',
})
export class AuthenticationService {
  private registerFarmerUrl: string = 'http://localhost:3000/farmer/register';
  private loginFarmerUrl: string = 'http://localhost:3000/farmer/login';

  private registerDealerUrl: string = 'http://localhost:3000/dealer/register';
  private loginDealerUrl: string = 'http://localhost:3000/dealer/login';

  private registerAdminUrl: string = 'http://localhost:3000/admin/register';
  private loginAdminUrl: string = 'http://localhost:3000/admin/login';

  constructor(private http: HttpClient, private snackBar: MatSnackBar) {}

  registerUser(body: IRegisterUser, type: string) {
    let url: string | null = null;
    if (type === 'farmer') {
      url = this.registerFarmerUrl;
    }
    if (type === 'dealer') {
      url = this.registerDealerUrl;
    }
    if (type === 'admin') {
      url = this.registerAdminUrl;
    }

    return this.http.post<any>(url!, body).toPromise();
  }

  loginUser(body: ILoginUser, type: string) {
    let url: string | null = null;
    if (type === 'farmer') {
      url = this.loginFarmerUrl;
    }
    if (type === 'dealer') {
      url = this.loginDealerUrl;
    }
    if (type === 'admin') {
      url = this.loginAdminUrl;
    }
    return this.http.post<any>(url!, body).toPromise();
  }

  getUserDetails() {
    const localStorageData = localStorage.getItem('user');
    if (!localStorageData) return null;
    const farmerDetails = JSON.parse(localStorageData);
    if (!farmerDetails) return null;
    return farmerDetails as IUser;
  }

  openSnackBar(message: string) {
    const action = undefined;
    const config = { duration: 2000 };
    this.snackBar.open(message, action, config);
  }

  handleErrors(error: HttpErrorResponse) {
    return throwError(error.message || 'Server Error');
  }
}
